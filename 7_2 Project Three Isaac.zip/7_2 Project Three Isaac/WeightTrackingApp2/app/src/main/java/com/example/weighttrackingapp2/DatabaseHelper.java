// Jordan Isaac Weight Tracking App CS360
package com.example.weighttrackingapp2;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


/**
 * DatabaseHelper handles creation and management of the local SQLite database.
 * It includes tables for storing users and weight entries.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version
    private static final String DATABASE_NAME = "weighttracker.db";
    private static final int DATABASE_VERSION = 1;

    // Table and column names for the "users" table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Table and column names for the "weights" table
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COL_WEIGHT_ID = "id";
    private static final String COL_WEIGHT_DATE = "date";
    private static final String COL_WEIGHT_VALUE = "weight";

    // Constructor that passes the database name and version to SQLiteOpenHelper
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called when the database is first created.
     * Defines the schema for the users and weights tables.
     */

    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create the users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT)";

        // SQL statement to create the weights table
        String CREATE_WEIGHTS_TABLE = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_WEIGHT_DATE + " TEXT, " +
                COL_WEIGHT_VALUE + " TEXT)";

        // Execute both SQL statements
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_WEIGHTS_TABLE);
    }

    /**
     * Called when the database needs to be upgraded.
     * Drops existing tables and recreates them.
     */

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        // Recreate tables
        onCreate(db);
    }


    // USER ACCOUNT METHODS

    // adds a new user to the database
    // @param username Username to store
    // @param password Password to store
    // @return true if insertion is successful, false otherwise
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1; // returns true if insert is successful
    }

    // Checks if a user exists in the database with the given username and password.
    // @return true if user exists, false otherwise
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    // WEIGHT ENTRY METHODS

    // adds weight entry to the database
    // @param date Date of the entry
    // @param weight Weight value
    // @return true if insertion is successful, false otherwise
    public boolean addWeightEntry(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_DATE, date);
        values.put(COL_WEIGHT_VALUE, weight);
        long result = db.insert(TABLE_WEIGHTS, null, values);
        return result != -1;
    }

    // Retrieves all weight entries from the database, ordered by most recent first.
    // @return Cursor containing all weight entries
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_WEIGHTS, null, null, null, null, null, COL_WEIGHT_ID + " DESC");
    }

    // Deletes a weight entry by ID.
    // @param id ID of the entry to delete
    // @return true if a row was deleted, false otherwise
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_WEIGHTS, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(id)}) > 0;
    }
}
