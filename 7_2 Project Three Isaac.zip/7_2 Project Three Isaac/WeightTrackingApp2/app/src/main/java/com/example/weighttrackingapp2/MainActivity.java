// Jordan Isaac Weight Tracking App CS360
package com.example.weighttrackingapp2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.Date;

/**
 * MainActivity handles the login screen of the Weight Tracking App.
 * Users can either log in or simulate account creation.
 */

public class MainActivity extends AppCompatActivity {

    // EditText fields for user input: username and password
    private EditText editUsername, editPassword;

    /**
     * Called when the activity is first created.
     * Sets up the UI and event listeners for buttons.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the layout for the activity to a constraint-based login screen
        setContentView(R.layout.activity_login_constraint);

        // Initialize input fields
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        // Initialize buttons for login and account creation
        Button btnLogin = findViewById(R.id.buttonLogin);
        Button btnCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Set login button behavior: navigate to DataActivity
        btnLogin.setOnClickListener(view -> startActivity(new Intent(this, DataActivity.class)));

        // Set account creation button behavior: show a demo toast message
        btnCreateAccount.setOnClickListener(view -> Toast.makeText(this, "Account Created (Demo)", Toast.LENGTH_SHORT).show());

        // Apply a slide animation transition when switching activities
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);

    }
}
