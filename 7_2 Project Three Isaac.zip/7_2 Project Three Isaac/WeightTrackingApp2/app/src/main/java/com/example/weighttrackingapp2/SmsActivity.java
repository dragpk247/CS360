// Jordan Isaac Weight Tracking App CS360
package com.example.weighttrackingapp2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.*;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.Date;

public class SmsActivity extends AppCompatActivity {

    // Request code for SMS permission
    private static final int SMS_PERMISSION_CODE = 101;

    // UI elements
    private TextView statusText;
    private Button btnRequestSMS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the app bar/banner at the top for a cleaner UI
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Load the layout for the SMS permission screen
        setContentView(R.layout.activity_sms);

        // Link UI elements
        statusText = findViewById(R.id.textSMSStatus);
        btnRequestSMS = findViewById(R.id.buttonRequestSMSPermission);

        // Set click listener for the SMS permission button
        btnRequestSMS.setOnClickListener(view -> {
            // Check if SEND_SMS permission is already granted
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                // Request SMS permission from the user
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                // If permission is already granted, send SMS
                sendGoalNotification();
            }
        });
    }

    // Function to send an SMS message and then transition to the weight tracking screen
    private void sendGoalNotification() {
        try {
            // Use SmsManager to send a text message
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("+1234567890", null,
                    "🎯 Goal reached! Congrats on your weight progress!",
                    null, null);
            // Show confirmation and update status
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
            statusText.setText("SMS sent: Goal reached!");

            // Navigate to the weight entry screen (DataActivity)/Transition to weight tracking
            new Handler().postDelayed(() -> {
                Intent intent = new Intent(SmsActivity.this, DataActivity.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }, 3000); // 3000ms = 3 seconds

        } catch (Exception e) {
            // Handle SMS failure case
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            statusText.setText("SMS sending failed");
        }
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            // If permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendGoalNotification(); // Send SMS now
            } else {
                // If permission denied, inform user and transition after a short delay
                Toast.makeText(this, "Permission denied. SMS disabled.", Toast.LENGTH_SHORT).show();
                statusText.setText("Permission denied. SMS feature not available.");

                // Automatically navigate to DataActivity after 2 seconds
                new Handler().postDelayed(() -> {
                    Intent intent = new Intent(SmsActivity.this, DataActivity.class);
                    startActivity(intent);
                    overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                }, 5000);
            }
        }
    }
}