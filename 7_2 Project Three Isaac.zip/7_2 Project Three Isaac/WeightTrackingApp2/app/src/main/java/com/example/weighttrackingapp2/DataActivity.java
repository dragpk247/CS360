// Jordan Isaac Weight Tracking App CS360
package com.example.weighttrackingapp2;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.Date;


/**
 * DataActivity allows users to input and track their weight entries in a table.
 * Users can also navigate to the SMS notification screen from here.
 */
public class DataActivity extends AppCompatActivity {

    //UI components
    private EditText editNewWeight;
    private TableLayout tableData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the default action bar for a cleaner UI
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Set the layout for this activity
        setContentView(R.layout.activity_data);

        // Initialize UI elements
        editNewWeight = findViewById(R.id.editNewWeight);
        tableData = findViewById(R.id.tableData);
        Button btnAddWeight = findViewById(R.id.buttonAddWeight);
        Button btnNext = findViewById(R.id.buttonToSMS);

        // Add weight entry to table when clicked
        btnAddWeight.setOnClickListener(view -> addWeightEntry());

        // Navigate to SmsActivity when clicked
        btnNext.setOnClickListener(view -> startActivity(new Intent(this, SmsActivity.class)));

        // Back to Login button setup
        Button btnBackToLogin = findViewById(R.id.buttonBackToLogin);
        btnBackToLogin.setOnClickListener(view -> {
            Intent intent = new Intent(DataActivity.this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        });

        // Apply slide transition animation
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);

    }


    // Adds a new weight entry to the table dynamically, with date and delete functionality.

    private void addWeightEntry() {
        String weight = editNewWeight.getText().toString();
        // Show message if weight input is empty
        if (weight.isEmpty()) {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }
        // Create a new table row
        TableRow row = new TableRow(this);

        // Set layout params for each column to ensure alignment and spacing
        TableRow.LayoutParams params = new TableRow.LayoutParams(
                0, TableRow.LayoutParams.WRAP_CONTENT, 1f);

        // Create date column
        TextView dateCol = new TextView(this);
        dateCol.setText(new Date().toString());
        dateCol.setPadding(8, 8, 8, 8);
        dateCol.setLayoutParams(params);


        // Create weight column with "lbs"
        TextView weightCol = new TextView(this);
        weightCol.setText(weight + " lbs");
        weightCol.setPadding(8, 8, 8, 8);
        weightCol.setLayoutParams(params);


        // Create delete button
        Button deleteBtn = new Button(this);
        deleteBtn.setText("Delete");
        deleteBtn.setPadding(8, 8, 8, 8);
        // Set delete functionality to remove the row from the table
        deleteBtn.setOnClickListener(view -> tableData.removeView(row));
        deleteBtn.setLayoutParams(params);




        // Add all columns to the row
        row.addView(dateCol);
        row.addView(weightCol);
        row.addView(deleteBtn);

        // Add the row to the table layout
        tableData.addView(row);

        // Clear input field for next entry
        editNewWeight.setText("");

        // Update text view to show the last entered weight
        TextView textViewEnteredWeight = findViewById(R.id.textViewEnteredWeight);
        textViewEnteredWeight.setText("Entered Weight: " + weight + " lbs");
    }
}